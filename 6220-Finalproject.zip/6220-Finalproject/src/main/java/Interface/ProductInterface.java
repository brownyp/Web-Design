package Interface;

public interface ProductInterface {
     String getImagesPath(String x);

}
