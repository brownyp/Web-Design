package controller;

import bean.Products;
import exception.ProductsException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
import dao.ProductsDAO;


@Controller
public class AdminController {
    @Autowired
    ProductsDAO productsDAO;


    @RequestMapping(value = "/admin",method = RequestMethod.GET)
    public String loadadmin()
    {
        return "admin/index";
    }

    @RequestMapping(value = "/login",method = RequestMethod.POST)
    public String login(@RequestParam("testlog") String testlog)
    {
        return "redirect:/admin/index";
    }
    @RequestMapping(value = "/admin/index",method = RequestMethod.POST)
    public String redirecttoP1() { return "admin/index"; }
    @RequestMapping(value = "manageProduct",method = RequestMethod.GET)
    public String manageProduct(Model model) throws ProductsException {
        List<Products> allproducts =  productsDAO.getproduct();
        model.addAttribute("product",allproducts);
        return "admin/manageProduct"; }

    @RequestMapping(value = "deleteProduct",method = RequestMethod.GET)
    public String deleteProduct() {



        return "admin/manageOrder"; }


    @RequestMapping(value = "manageOrder",method = RequestMethod.GET)
    public String managerorder() { return "admin/manageOrder"; }

    @RequestMapping(value = "logout",method = RequestMethod.GET)
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.invalidate();
        return "user/index"; }


}
